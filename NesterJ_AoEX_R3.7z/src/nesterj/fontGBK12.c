//gbk����
const unsigned char _gbk_fontSong12[]={
#include "font12X12_9.c"
};
	
const unsigned short *gbk_fontSong12=(unsigned short*)_gbk_fontSong12;

//���Ӣ��
const unsigned char _asc_font12[]={
#include "font12X6_9.c"
};
	
const unsigned short *asc_font12=(unsigned short*)_asc_font12;
