

#include "nes_apu.h"

#ifdef __cplusplus
extern "C" {
#endif
extern apuext_t fds_ext;
extern apuext_t fds_dll_ext;
extern apuext_t fds_nesp_ext;
#ifdef __cplusplus
}
#endif
