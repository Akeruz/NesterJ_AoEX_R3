
#include "nes_apu.h"

#ifdef __cplusplus
extern "C" {
#endif
extern apuext_t vrc6_ext;
	
#ifdef __cplusplus
}
#endif
