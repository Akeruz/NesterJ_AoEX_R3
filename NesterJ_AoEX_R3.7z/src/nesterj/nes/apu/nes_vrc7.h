
#include "nes_apu.h"

#ifdef __cplusplus
extern "C" {
#endif
extern apuext_t vrc7_ext;
	
#ifdef __cplusplus
}
#endif
