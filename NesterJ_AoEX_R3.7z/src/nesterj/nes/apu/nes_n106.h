

#include "nes_apu.h"

#ifdef __cplusplus
extern "C" {
#endif
extern apuext_t n106_ext;
	
#ifdef __cplusplus
}
#endif
