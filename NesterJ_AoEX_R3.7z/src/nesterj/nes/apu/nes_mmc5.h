
#include "nes_apu.h"

#ifdef __cplusplus
extern "C" {
#endif
extern apuext_t mmc5_ext;
	
#ifdef __cplusplus
}
#endif
