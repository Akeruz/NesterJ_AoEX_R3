
/////////////////////////////////////////////////////////////////////
// Mapper 1
void NES_mapper1_Reset();
void NES_mapper1_MMC1_set_CPU_banks();
void NES_mapper1_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void NES_mapper1_MemoryWrite(uint32 addr, uint8 data);

void NES_mapper1_Init();
/////////////////////////////////////////////////////////////////////

