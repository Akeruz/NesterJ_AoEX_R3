
void BmcCtc65_Init();
void BmcCtc65_Reset();
void BmcCtc65_UpdateChrPrg();

void BmcCtc65_MemoryWrite(uint32 addr, uint8 data);
void BmcCtc65_MemoryReadSaveRAM(uint32 addr);
