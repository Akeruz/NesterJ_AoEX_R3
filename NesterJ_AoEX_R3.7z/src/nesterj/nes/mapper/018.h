
/////////////////////////////////////////////////////////////////////
// Mapper 18
void NES_mapper18_Reset();
void NES_mapper18_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper18_HSync(uint32 scanline);
void NES_mapper18_SNSS_fixup();

void NES_mapper18_Init();
/////////////////////////////////////////////////////////////////////

