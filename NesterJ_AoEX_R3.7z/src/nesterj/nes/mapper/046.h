
/////////////////////////////////////////////////////////////////////
// Mapper 46
void NES_mapper46_Reset();
void NES_mapper46_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void NES_mapper46_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper46_set_rom_banks();

void NES_mapper46_Init();
/////////////////////////////////////////////////////////////////////

