
/////////////////////////////////////////////////////////////////////
// Mapper 252
void NES_mapper252_Reset();
void NES_mapper252_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper252_Clock(int cycles );

//void NES_mapper252_HSync(uint32 scanline);
void NES_mapper252_HSync(uint32 scanline);

void NES_mapper252_Init();
/////////////////////////////////////////////////////////////////////

