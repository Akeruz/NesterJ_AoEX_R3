
/////////////////////////////////////////////////////////////////////
// UnlSHeroes
void UnlSHeroes_Reset();
uint8 UnlSHeroes_MemoryReadLow(uint32 addr);
void UnlSHeroes_MemoryWriteLow(uint32 addr, uint8 data);
void UnlSHeroes_UpdateChr(unsigned int A, unsigned int V);

void UnlSHeroes_Init();
/////////////////////////////////////////////////////////////////////

