
/////////////////////////////////////////////////////////////////////
// Mapper 91
void NES_mapper91_Reset();
void NES_mapper91_MemoryWriteSaveRAM(uint32 addr, uint8 data);
//void NES_mapper91_MemoryWriteLow(uint32 addr, uint8 data);
void NES_mapper91_HSync(uint32 scanline);

void NES_mapper91_Init();
/////////////////////////////////////////////////////////////////////

