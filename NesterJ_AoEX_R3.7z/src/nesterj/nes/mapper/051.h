
/////////////////////////////////////////////////////////////////////
// Mapper 51
void NES_mapper51_Reset();
void NES_mapper51_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void NES_mapper51_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper51_Sync_Prg_Banks();

void NES_mapper51_Init();
/////////////////////////////////////////////////////////////////////

