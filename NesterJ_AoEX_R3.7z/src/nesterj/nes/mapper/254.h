
/////////////////////////////////////////////////////////////////////
// Mapper 254
void NES_mapper254_Reset();
void NES_mapper254_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper254_MemoryReadSaveRAM(uint32 addr);
void NES_mapper254_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper254_HSync(uint32 scanline);

void NES_mapper254_Init();
/////////////////////////////////////////////////////////////////////

