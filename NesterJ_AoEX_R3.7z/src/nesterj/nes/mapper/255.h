
/////////////////////////////////////////////////////////////////////
// Mapper 255
void NES_mapper255_Reset();
void NES_mapper255_MemoryWrite(uint32 addr, uint8 data);
uint8 NES_mapper255_MemoryReadLow(uint32 addr);
void NES_mapper255_MemoryWriteLow(uint32 addr, uint8 data);

void NES_mapper255_Init();
/////////////////////////////////////////////////////////////////////

