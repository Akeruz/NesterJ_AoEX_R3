
/////////////////////////////////////////////////////////////////////
// Mapper 25
void NES_mapper25_Reset();
void NES_mapper25_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper25_HSync(uint32 scanline);
void NES_mapper25_SNSS_fixup();

void NES_mapper25_Init();
/////////////////////////////////////////////////////////////////////

