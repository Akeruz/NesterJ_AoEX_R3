
/////////////////////////////////////////////////////////////////////
// Mapper 62
void NES_mapper62_Reset();
void NES_mapper62_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper62_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void NES_mapper62_MemoryWriteLow(uint32 addr, uint8 data);

void NES_mapper62_Init();
/////////////////////////////////////////////////////////////////////

