
/////////////////////////////////////////////////////////////////////
// Mapper 167
void NES_mapper167_Reset();

void NES_mapper167_MemoryWrite(uint32 addr, uint8 data);

void NES_mapper167_MMC3_set_CPU_banks();
void NES_mapper167_MMC3_set_PPU_banks();

void NES_mapper167_Init();
/////////////////////////////////////////////////////////////////////

