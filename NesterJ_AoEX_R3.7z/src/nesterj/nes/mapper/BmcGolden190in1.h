//Golden190in1_Init

void Golden190in1_Reset();
void Golden190in1_MemoryWrite(uint32 addr, uint8 data);
void Golden190in1_Init();