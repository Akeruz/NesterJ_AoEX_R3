void BmcWs_Reset();
void BmcWs_Init();
void Poke_BmcWs_600X(uint32 A,uint8 V);
void Poke_BmcWs_6000(uint32 A,uint8 V);
void Poke_BmcWs_6001(uint32 A,uint8 V);
