
/////////////////////////////////////////////////////////////////////
// Mapper 6
void NES_mapper6_Reset();
void NES_mapper6_MemoryWriteLow(uint32 addr, uint8 data);
void NES_mapper6_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper6_HSync(uint32 scanline);

void NES_mapper6_Init();
/////////////////////////////////////////////////////////////////////

