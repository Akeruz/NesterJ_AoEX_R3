
/////////////////////////////////////////////////////////////////////
// Mapper 95
void NES_mapper95_Reset();
void NES_mapper95_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper95_SNSS_fixup();
void NES_mapper95_MMC3_set_PPU_banks();
void NES_mapper95_MMC3_set_CPU_banks();

void NES_mapper95_Init();
/////////////////////////////////////////////////////////////////////

