void A65as_Init();
void A65as_Reset();
void A65as_MemoryWrite(uint32 A, uint8 V);