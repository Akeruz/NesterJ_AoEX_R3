
/////////////////////////////////////////////////////////////////////
// Mapper 249
void NES_mapper249_Reset();
void NES_mapper249_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper249_MemoryWriteLow(uint32 addr, uint8 data);

void NES_mapper249_HSync( uint32 scanline );
void NES_mapper249_Init();
/////////////////////////////////////////////////////////////////////

