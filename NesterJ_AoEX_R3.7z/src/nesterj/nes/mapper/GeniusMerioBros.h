void GeniusMerioBros_Init();
void GeniusMerioBros_Reset();
void GeniusMerioBros_MemoryWriteSaveRAM(uint32 A, uint8 V);
void GeniusMerioBros_MemoryReadSaveRAM(uint32 A);