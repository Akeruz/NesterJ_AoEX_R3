
/////////////////////////////////////////////////////////////////////
// Mapper 96
void NES_mapper96_Reset();
void NES_mapper96_PPU_Latch_Address(uint32 addr);
void NES_mapper96_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper96_sync_PPU_banks();

void NES_mapper96_Init();
/////////////////////////////////////////////////////////////////////

