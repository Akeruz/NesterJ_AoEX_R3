
/////////////////////////////////////////////////////////////////////
// Mapper 21
void NES_mapper21_Reset();
void NES_mapper21_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper21_HSync(uint32 scanline);
void NES_mapper21_SNSS_fixup();

void NES_mapper21_Init();
/////////////////////////////////////////////////////////////////////

