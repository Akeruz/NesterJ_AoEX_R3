//"UNL-N625092",UNL_N625092

void N625092_Reset();
void N625092_Init();
void N625092_UpdatePrg();
void N625092_MemoryWrite(uint32 addr, uint8 data);
