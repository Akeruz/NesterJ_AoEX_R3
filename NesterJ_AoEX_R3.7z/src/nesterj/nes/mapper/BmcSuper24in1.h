
/////////////////////////////////////////////////////////////////////
// BmcSuper24in1
void BmcSuper24in1_Reset();
void BmcSuper24in1_MemoryWriteLow(uint32 addr, uint8 data);
void BmcSuper24in1_UpdatePrg(unsigned int A,unsigned int V);
void BmcSuper24in1_UpdateChr(unsigned int A,unsigned int V);

void BmcSuper24in1_Init();
/////////////////////////////////////////////////////////////////////

