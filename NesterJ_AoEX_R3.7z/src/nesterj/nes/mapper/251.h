
/////////////////////////////////////////////////////////////////////
// Mapper 251
void NES_mapper251_Reset();
void NES_mapper251_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper251_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void NES_mapper251_banksync();

void NES_mapper251_Init();
/////////////////////////////////////////////////////////////////////

