//////////////////////////////////////////////////////////////////////////
// Mapper142  SMB2J                                                     //
//////////////////////////////////////////////////////////////////////////
void NES_mapper142_Reset();
void NES_mapper142_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper142_HSync(uint32 scanline);
void NES_mapper142_SetBank();
void NES_mapper142_Init();
