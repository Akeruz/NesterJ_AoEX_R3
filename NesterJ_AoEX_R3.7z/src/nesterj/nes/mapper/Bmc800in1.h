void Game800in1_Init();
void Game800in1_Reset();
void Game800in1_MemoryWrite(uint32 A, uint8 V);
void Game800in1_MemoryReadSaveRAM(uint32 V);

