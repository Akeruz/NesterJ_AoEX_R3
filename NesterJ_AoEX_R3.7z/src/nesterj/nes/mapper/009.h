
/////////////////////////////////////////////////////////////////////
// Mapper 9
void NES_mapper9_Reset();
void NES_mapper9_PPU_Latch_FDFE(uint32 addr);
void NES_mapper9_set_VROM_0000();
void NES_mapper9_set_VROM_1000();
void NES_mapper9_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper9_SNSS_fixup();

void NES_mapper9_Init();
/////////////////////////////////////////////////////////////////////

