//"BMC-64IN1NOREPEAT",BMC_Y2K_64IN1

void BmcY2k64in1_Reset();
void BmcY2k64in1_Init();
void Y2k64in1_Update();
void BmcY2k64in1_MemoryWrite(uint32 addr, uint8 data);
void BmcY2k64in1_MemoryWriteLow(uint32 A, uint8 V);