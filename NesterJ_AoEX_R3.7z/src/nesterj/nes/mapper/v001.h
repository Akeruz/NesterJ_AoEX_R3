
void VNES_mapper1_Reset();
void VNES_mapper1_MMC1_set_CPU_banks();
void VNES_mapper1_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void VNES_mapper1_MemoryWrite(uint32 addr, uint8 data);

void VNES_mapper1_Init();