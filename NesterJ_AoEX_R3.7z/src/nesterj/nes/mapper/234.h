
/////////////////////////////////////////////////////////////////////
// Mapper 234
void NES_mapper234_Reset();
void NES_mapper234_MemoryReadSaveRAM(uint32 addr);
void NES_mapper234_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper234_Sync();

void NES_mapper234_Init();
/////////////////////////////////////////////////////////////////////

