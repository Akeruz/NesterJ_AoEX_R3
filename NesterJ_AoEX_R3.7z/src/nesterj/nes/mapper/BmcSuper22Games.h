//"BMC-42IN1RESETSWITCH",BMC_SUPER_22GAMES
void BmcSupper22Games_Reset();
void BmcSupper22Games_Init();
void BmcSupper22Games_MemoryWrite(uint32 addr, uint8 data);