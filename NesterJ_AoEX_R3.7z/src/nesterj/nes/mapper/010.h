
/////////////////////////////////////////////////////////////////////
// Mapper 10
void NES_mapper10_Reset();
void NES_mapper10_PPU_Latch_FDFE(uint32 addr);
void NES_mapper10_set_VROM_0000();
void NES_mapper10_set_VROM_1000();
void NES_mapper10_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper10_SNSS_fixup();

void NES_mapper10_Init();
/////////////////////////////////////////////////////////////////////

