void BmcHero_Init();
void BmcHero_Reset();
void BmcHero_UpdatePrg(unsigned int,unsigned int);
void BmcHero_UpdateChr(unsigned int,unsigned int);
void BmcHero_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void BmcHero_MemoryReadSaveRAM(uint32 addr);
