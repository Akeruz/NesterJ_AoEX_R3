
/////////////////////////////////////////////////////////////////////
// Mapper 243
void NES_mapper243_Reset();
void NES_mapper243_MemoryWriteLow(uint32 addr, uint8 data);
void NES_mapper243_MemoryWriteSaveRAM(uint32 addr, uint8 data);

void NES_mapper243_Init();
/////////////////////////////////////////////////////////////////////

