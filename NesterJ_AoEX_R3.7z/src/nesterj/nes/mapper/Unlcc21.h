void Unlcc21_Reset();
void Unlcc21_Init();
void Unlcc21_MemoryWrite(uint32 addr, uint8 data);
/////////////////////////////////////////////////////////////////////

void BmcD1038_Reset();
void BmcD1038_Init();
void BmcD1038_MemoryWrite(uint32 addr, uint8 data);
void BmcD1038_MemoryReadSaveRAM(uint32 addr);

