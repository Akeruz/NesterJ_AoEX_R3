
/////////////////////////////////////////////////////////////////////
// Mapper 44
void NES_mapper44_Reset();
void NES_mapper44_MemoryWrite(uint32 addr, uint8 data);
void NES_mapper44_HSync(uint32 scanline);
void NES_mapper44_MMC3_set_CPU_banks();
void NES_mapper44_MMC3_set_PPU_banks();

void NES_mapper44_Init();
/////////////////////////////////////////////////////////////////////

