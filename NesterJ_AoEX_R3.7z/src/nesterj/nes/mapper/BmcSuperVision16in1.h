

void BmcSV16in1_Init();
void BmcSV16in1_Reset();
void BmcSV16in1_UpdatePrg();
void BmcSV16in1_MemoryWrite(uint32 addr, uint8 data);
void BmcSV16in1_MemoryWriteSaveRAM(uint32 addr, uint8 data);
void BmcSV16in1_MemoryReadSaveRAM(uint32 addr);