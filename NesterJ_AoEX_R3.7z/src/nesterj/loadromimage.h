#ifndef LOADROMIMAGE_H
#define LOADROMIMAGE_H

// load rom image by ruka
uint32 load_rom_image(uint8 *buf, uint32 bufLen, const char *szRomPath);

#endif
