// primitive graphics for Hello World PSP
#ifndef PGGBK_H_
#define PGGBK_H_

void pgPrintGBK12(unsigned long x,unsigned long y,unsigned long color,const char *str);
void mh_printGBK12(int x,int y,const char *str,int col);


#endif
