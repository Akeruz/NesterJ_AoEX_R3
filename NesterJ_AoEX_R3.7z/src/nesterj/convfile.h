#ifndef CONVFILE_H
#define CONVFILE_H

void ConvertThumbnailFile(void);

#endif

